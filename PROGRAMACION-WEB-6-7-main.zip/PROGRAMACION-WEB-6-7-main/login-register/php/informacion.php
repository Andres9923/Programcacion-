<!DOCTYPE Html>
<Html>

<head>
    <link rel="stylesheet" href="../assets/css/index.css">
    <MEta charset="utf-8" />
    <title>Biblioteca web</title>
</head>

<body>

    <h1>Biblioteca</h1>
    <h2>Categoria de libros</h2>
    <ul>
        <li>
            <a href="index.html">Inicio</a>
        </li>
        <li>
            <a href="index.html">Categoria</a>
        </li>
        <li>
            <a href="Info.html">Informacion</a>
        </li>
        <li>
            <a href="Info.html">Secion</a>
        </li <hr>
        <p> </p>
        <h1>Tipos</h1>
        <ol>
            <li>Tecnologia</li>
            <li>Ciencia</li>
            <li>Religion</li>
            <li>Geografia</li>
            <li>Generalidades</li>
            <li>Filosofia</li>
        </ol>
        <hr>
        <h1>Sugerencia </h1>
        <h2>Mobidic</h2>
        <img width="160px" src="https://covers.alibrate.com/b/59872eabcba2bce50c1eb8ee/f95e302e-cedb-43ac-81ed-7fbccb785224/medium" alt="">
        <h4>Moby Dick​ es una novela del escritor Herman Melville publicada en 1851. Narra la travesía del barco ballenero Pequod, comandado por el capitán Ahab, junto a Ismael y el arponero Queequeg en la obsesiva y autodestructiva persecución de un gran cachalote blanco.</h4>
</body>

</Html>